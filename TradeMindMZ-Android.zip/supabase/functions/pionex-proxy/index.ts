/**
 * pionex-proxy Edge Function
 *
 * Handles all Pionex API calls server-side. Credentials never touch the frontend.
 *
 * Actions:
 *   connect       — validate + store API key/secret (encrypted)
 *   disconnect    — remove stored credentials
 *   portfolio     — fetch balances, open orders, running bots, USDT-M positions (READ-ONLY)
 *   positions     — fetch USDT-M futures positions only (lightweight refresh, READ-ONLY)
 *   market_data   — fetch Pionex tickers (public, no auth)
 *   candlestick   — fetch kline data for a symbol (public, no auth)
 *
 * USDT-M Futures positions endpoint:
 *   GET https://api.pionex.com/uapi/v1/account/positions
 *   Auth: same HMAC-SHA256 signing as /api/v1/* (PIONEX-KEY + PIONEX-SIGNATURE headers)
 *   This is the internal futures API surface (uapi prefix), distinct from the spot API (api prefix).
 *   Verified live: returns HTTP 200 + APIKEY_LOST when unauthenticated (route exists).
 *
 * READ-ONLY: No write operations. No create/cancel order, no close position, no transfer.
 */

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const PIONEX_BASE = 'https://api.pionex.com';

// USDT-M futures endpoint — verified to exist (HTTP 200 + APIKEY_LOST unauthenticated)
// Spot endpoint /api/v1/account/positions → 404 (does NOT exist)
const PIONEX_USDTM_POSITIONS_PATH = '/uapi/v1/account/positions';

// ─── Symbol display normalisation ─────────────────────────────────────────────
// Pionex internal format: RIF_USDT_PERP  →  display: RIF/USDT Perp
// Also handles: BTCUSDT_PERP, BTC_USDT, BTC/USDT etc.
function normaliseSymbolDisplay(raw: string): string {
  // Remove _PERP suffix variants for display, then reformat
  const s = raw.toUpperCase();
  // e.g. RIF_USDT_PERP → RIF/USDT Perp
  const perpMatch = s.match(/^([A-Z0-9]+)[_/]?(USDT|USDC|BUSD|BNB|BTC|ETH|USD)_(PERP|SWAP|FUTURES?)$/);
  if (perpMatch) return `${perpMatch[1]}/${perpMatch[2]} Perp`;
  // e.g. RIFUSDT_PERP or RIFUSDTPERP
  const perpMatch2 = s.match(/^([A-Z0-9]+)(USDT|USDC|BUSD|BTC|ETH)_(PERP|SWAP)$/);
  if (perpMatch2) return `${perpMatch2[1]}/${perpMatch2[2]} Perp`;
  // e.g. RIF_USDT or RIF/USDT (spot-like)
  const spotMatch = s.match(/^([A-Z0-9]+)[_/](USDT|USDC|BUSD|BNB|BTC|ETH|USD)$/);
  if (spotMatch) return `${spotMatch[1]}/${spotMatch[2]}`;
  // Fallback: replace underscores with slashes
  return raw.replace(/_/g, '/');
}

// ─── Encryption (XOR + base64, key from env) ──────────────────────────────

async function encryptSecret(secret: string): Promise<string> {
  const key = Deno.env.get('ENCRYPTION_KEY') ?? 'default-key-change-this-now';
  const keyBytes = new TextEncoder().encode(key);
  const secretBytes = new TextEncoder().encode(secret);
  const encrypted = new Uint8Array(secretBytes.length);
  for (let i = 0; i < secretBytes.length; i++) encrypted[i] = secretBytes[i] ^ keyBytes[i % keyBytes.length];
  return btoa(String.fromCharCode(...encrypted));
}

async function decryptSecret(enc: string): Promise<string> {
  const key = Deno.env.get('ENCRYPTION_KEY') ?? 'default-key-change-this-now';
  const keyBytes = new TextEncoder().encode(key);
  const encBytes = new Uint8Array(atob(enc).split('').map(c => c.charCodeAt(0)));
  const dec = new Uint8Array(encBytes.length);
  for (let i = 0; i < encBytes.length; i++) dec[i] = encBytes[i] ^ keyBytes[i % keyBytes.length];
  return new TextDecoder().decode(dec);
}

// ─── Pionex HMAC-SHA256 Signing ───────────────────────────────────────────
//
// Official spec (pionex-official/pionex-open-api openapi.yaml):
//   GET:  HMAC-SHA256(secret, "GET"  + path + "?" + sorted_params)
//   POST: HMAC-SHA256(secret, "POST" + path + "?" + sorted_params + body_json)
//
//   Rules:
//   - Sort params alphabetically by key
//   - NO URL-encoding in the string being signed (use raw values)
//   - Output: lowercase hex (NOT base64)
//   - Send as header: PIONEX-SIGNATURE
//   - Send key as header: PIONEX-KEY
//   - timestamp (ms) included as a regular query param

async function buildPionexSignature(
  method: string,
  path: string,
  params: Record<string, string>,
  apiSecret: string,
  body = ''
): Promise<string> {
  // Sort alphabetically, raw values (no encodeURIComponent) for signing
  const sorted = Object.keys(params).sort().map(k => `${k}=${params[k]}`).join('&');
  const msg = `${method}${path}?${sorted}${body}`;

  const key = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(apiSecret),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(msg));
  // Convert to lowercase hex
  return Array.from(new Uint8Array(sig)).map(b => b.toString(16).padStart(2, '0')).join('');
}

async function pionexAuthRequest(
  method: string,
  path: string,
  apiKey: string,
  apiSecret: string,
  queryParams: Record<string, string> = {}
) {
  const timestamp = Date.now().toString();
  const params: Record<string, string> = { ...queryParams, timestamp };

  const signature = await buildPionexSignature(method, path, params, apiSecret);

  // URL uses encodeURIComponent for safe transport (only in URL, not in signing string)
  const qs = Object.keys(params).sort().map(k => `${k}=${encodeURIComponent(params[k])}`).join('&');
  const url = `${PIONEX_BASE}${path}?${qs}`;

  const res = await fetch(url, {
    method,
    headers: {
      'PIONEX-KEY': apiKey,
      'PIONEX-SIGNATURE': signature,
      'Content-Type': 'application/json',
    },
    signal: AbortSignal.timeout(10000),
  });

  const responseText = await res.text();
  if (!res.ok) throw new Error(`Pionex ${res.status}: ${responseText}`);

  const json = JSON.parse(responseText);
  if (json.result === false) {
    throw new Error(`${json.message ?? json.code ?? 'Unknown Pionex error'}`);
  }
  return json;
}

// Raw version: returns full JSON without throwing on result:false.
// Use for futures endpoints where the response shape is unknown — we need to
// see the actual payload even when authentication partially succeeds/fails.
async function pionexRawRequest(
  method: string,
  path: string,
  apiKey: string,
  apiSecret: string,
  queryParams: Record<string, string> = {}
): Promise<{ httpStatus: number; body: Record<string, unknown> }> {
  const timestamp = Date.now().toString();
  const params: Record<string, string> = { ...queryParams, timestamp };
  const signature = await buildPionexSignature(method, path, params, apiSecret);
  const qs = Object.keys(params).sort().map(k => `${k}=${encodeURIComponent(params[k])}`).join('&');
  const url = `${PIONEX_BASE}${path}?${qs}`;

  const res = await fetch(url, {
    method,
    headers: {
      'PIONEX-KEY': apiKey,
      'PIONEX-SIGNATURE': signature,
      'Content-Type': 'application/json',
    },
    signal: AbortSignal.timeout(10000),
  });

  const text = await res.text();
  let body: Record<string, unknown> = {};
  try { body = JSON.parse(text); } catch { body = { raw_text: text }; }
  return { httpStatus: res.status, body };
}

// ─── Main Handler ─────────────────────────────────────────────────────────

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const authHeader = req.headers.get('Authorization');
  if (!authHeader) {
    return new Response(JSON.stringify({ error: 'Unauthorized' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
  );

  // Verify JWT and get user
  const { data: { user }, error: authErr } = await supabase.auth.getUser(
    authHeader.replace('Bearer ', '')
  );
  if (authErr || !user) {
    return new Response(JSON.stringify({ error: 'Invalid token' }), {
      status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const body = await req.json().catch(() => ({}));
  const { action, api_key, api_secret, symbol, interval = '15M', limit = 50 } = body;

  const respond = (data: unknown, status = 200) =>
    new Response(JSON.stringify(data), {
      status, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  try {
    // ── PUBLIC: market data (no Pionex auth required) ──────────────────────

    if (action === 'market_data') {
      const res = await fetch(`${PIONEX_BASE}/api/v1/market/tickers`, {
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) throw new Error(`Pionex tickers ${res.status}`);
      const body = await res.json();
      return respond(body?.data ?? {});
    }

    if (action === 'candlestick') {
      if (!symbol) return respond({ error: 'symbol required' }, 400);
      const url = `${PIONEX_BASE}/api/v1/market/klines?symbol=${encodeURIComponent(symbol)}&interval=${interval}&limit=${limit}`;
      const res = await fetch(url, { signal: AbortSignal.timeout(6000) });
      if (!res.ok) throw new Error(`Pionex klines ${res.status}`);
      const kdata = await res.json();
      return respond(kdata?.data ?? {});
    }

    // ── AUTHENTICATED: account actions ────────────────────────────────────

    if (action === 'connect') {
      if (!api_key?.trim() || !api_secret?.trim())
        return respond({ error: 'API key and secret required' }, 400);

      // Validate credentials against Pionex account endpoint
      try {
        await pionexAuthRequest('GET', '/api/v1/account/balances', api_key.trim(), api_secret.trim());
      } catch (e) {
        const msg = String(e);
        // "request auth status failed" = key is valid but IP whitelist blocks this server
        if (msg.includes('request auth status failed') || msg.includes('auth status')) {
          return respond({
            error: 'IP-begrensning blokkerer tilgang. Gå til Pionex → API-administrasjon → rediger nøkkelen din og velg "Ingen IP-begrensning" (eller legg til 0.0.0.0/0). Supabase-serveren har en annen IP enn din hjemme-IP.',
            code: 'IP_WHITELIST_BLOCKED',
          }, 400);
        }
        // INVALID_APIKEY / INVALID_SIGNATURE
        if (msg.includes('INVALID_APIKEY') || msg.includes('Invalid apikey')) {
          return respond({ error: 'API-nøkkelen ble ikke funnet på Pionex. Sjekk at du kopierte riktig nøkkel.', code: 'INVALID_KEY' }, 400);
        }
        if (msg.includes('INVALID_SIGNATURE') || msg.includes('Signature')) {
          return respond({ error: 'Signaturfeil. Sjekk at API-hemmeligheten (Secret) er riktig kopiert uten ekstra mellomrom.', code: 'INVALID_SECRET' }, 400);
        }
        return respond({ error: `Pionex-feil: ${msg}` }, 400);
      }

      const encryptedSecret = await encryptSecret(api_secret.trim());
      const { error: upsertErr } = await supabase.from('pionex_connections').upsert({
        user_id: user.id,
        api_key: api_key.trim(),
        api_secret_encrypted: encryptedSecret,
        is_connected: true,
        last_sync: new Date().toISOString(),
        permissions: ['read'],
      }, { onConflict: 'user_id' });

      if (upsertErr) throw upsertErr;
      return respond({ success: true, permissions: ['read'] });
    }

    if (action === 'disconnect') {
      await supabase.from('pionex_connections').delete().eq('user_id', user.id);
      return respond({ success: true });
    }

    if (action === 'portfolio') {
      const { data: conn } = await supabase
        .from('pionex_connections')
        .select('api_key, api_secret_encrypted, is_connected')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!conn?.is_connected)
        return respond({ error: 'Pionex not connected' }, 404);

      const apiSecret = await decryptSecret(conn.api_secret_encrypted);

      // Fetch balances + open orders + bots in parallel — READ-ONLY
      // Positions are fetched separately via pionexRawRequest (never throws on result:false)
      const [balRes, ordRes, botRes] = await Promise.allSettled([
        pionexAuthRequest('GET', '/api/v1/account/balances', conn.api_key, apiSecret),
        pionexAuthRequest('GET', '/api/v1/trade/openOrders', conn.api_key, apiSecret, { limit: '20' }),
        pionexAuthRequest('GET', '/api/v1/bot/orders', conn.api_key, apiSecret, { limit: '20' }),
      ]);

      // USDT-M futures positions — use raw fetcher so result:false is visible, not swallowed
      const { httpStatus: posHttp, body: posBody } = await pionexRawRequest(
        'GET', PIONEX_USDTM_POSITIONS_PATH, conn.api_key, apiSecret
      );
      console.log('[portfolio/positions] HTTP', posHttp,
        '| result:', posBody.result, '| code:', posBody.code,
        '| message:', posBody.message,
        '| data keys:', posBody.data != null ? Object.keys(posBody.data as object) : 'null');

      const balances = balRes.status === 'fulfilled'
        ? ((balRes.value?.data?.balances ?? []) as Record<string, unknown>[])
            .map(b => ({
              coin: String(b.coinType ?? b.coin ?? ''),
              free: parseFloat(String(b.free ?? 0)),
              freeze: parseFloat(String(b.frozen ?? b.freeze ?? 0)),
              total: parseFloat(String(b.free ?? 0)) + parseFloat(String(b.frozen ?? b.freeze ?? 0)),
              usd_value: 0,
            }))
            .filter(b => b.total > 0)
        : [];

      const open_orders = ordRes.status === 'fulfilled'
        ? ((ordRes.value?.data?.orders ?? ordRes.value?.data?.list ?? []) as Record<string, unknown>[])
            .map(o => ({
              id: String(o.orderId ?? o.id ?? ''),
              symbol: String(o.symbol ?? ''),
              side: String(o.side ?? ''),
              price: parseFloat(String(o.price ?? 0)),
              qty: parseFloat(String(o.amount ?? o.size ?? 0)),
              created_at: o.createTime
                ? new Date(Number(o.createTime)).toISOString()
                : new Date().toISOString(),
            }))
        : [];

      // Bots: map from /api/v1/bot/orders response (gracefully empty if permission not granted)
      const bots = botRes.status === 'fulfilled'
        ? ((botRes.value?.data?.orders ?? botRes.value?.data?.list ?? []) as Record<string, unknown>[])
            .map(b => ({
              id: String(b.botOrderId ?? b.orderId ?? b.id ?? ''),
              name: String(b.botType ?? b.type ?? 'Grid Bot'),
              pair: String(b.symbol ?? ''),
              investment: parseFloat(String(b.investment ?? b.totalInvestment ?? 0)),
              total_pnl: parseFloat(String(b.totalProfit ?? b.pnl ?? 0)),
              roi_pct: parseFloat(String(b.roi ?? 0)) * 100,
              status: String(b.state ?? b.status ?? 'running'),
              created_at: b.createTime
                ? new Date(Number(b.createTime)).toISOString()
                : new Date().toISOString(),
            }))
        : [];

      // ── USDT-M Futures positions — parse raw response ─────────────────────
      let rawPositions: Record<string, unknown>[] = [];
      let positionsFetched = false;
      let positionsApiError: string | null = null;

      if (posBody.result === false || posHttp !== 200) {
        positionsApiError = String(posBody.message ?? posBody.code ?? `HTTP ${posHttp}`);
        console.warn('[portfolio/positions] error:', positionsApiError);
      } else {
        positionsFetched = true;
        const d = posBody.data as Record<string, unknown> | null;
        if (Array.isArray(posBody.data))          rawPositions = posBody.data as Record<string, unknown>[];
        else if (d && Array.isArray(d.positions)) rawPositions = d.positions as Record<string, unknown>[];
        else if (d && Array.isArray(d.list))      rawPositions = d.list as Record<string, unknown>[];
        else if (d && Array.isArray(d.data))      rawPositions = d.data as Record<string, unknown>[];
        console.log('[portfolio/positions] raw count:', rawPositions.length,
          '| symbols:', rawPositions.map((p: Record<string, unknown>) => p.symbol ?? '?').join(',') || '(none)');
      }

      // ── portfolio/positions: same normalisation as the standalone positions action ──
      // resolveQty helper (scoped): skip zeros, prefer size over positionAmt
      const portfolioResolveQty = (p: Record<string, unknown>): { value: number; field: string } => {
        const candidates: Array<[string, unknown]> = [
          // Confirmed Pionex field: netSize = -520 (signed)
          ['netSize',      p.netSize],
          ['positionAmt',  p.positionAmt],
          ['size',         p.size],
          ['quantity',     p.quantity],
          ['qty',          p.qty],
          ['amount',       p.amount],
          ['vol',          p.vol],
          ['volume',       p.volume],
          ['pos',          p.pos],
          ['net',          p.net],
          ['holdSize',     p.holdSize],
          ['currentQty',   p.currentQty],
        ];
        for (const [field, val] of candidates) {
          if (val !== undefined && val !== null && val !== '') {
            const n = parseFloat(String(val));
            // Skip NaN and exact zero — a zero qty means closed position
            // We want the first non-zero value (e.g. size=-520 beats positionAmt=0)
            if (!isNaN(n) && n !== 0) return { value: n, field };
          }
        }
        for (const [field, val] of candidates) {
          if (val !== undefined && val !== null && val !== '') {
            const n = parseFloat(String(val));
            if (!isNaN(n)) return { value: n, field };
          }
        }
        return { value: 0, field: 'none' };
      };

      const positions = rawPositions
        .map(p => {
          const rawSymbol    = String(p.symbol ?? p.pair ?? p.contract ?? '');
          const explicitSide = String(p.positionSide ?? p.side ?? '').toUpperCase();
          const { value: rawQtyVal } = portfolioResolveQty(p);

          let side: 'LONG' | 'SHORT';
          if (explicitSide === 'SHORT')     side = 'SHORT';
          else if (explicitSide === 'LONG') side = 'LONG';
          else                              side = rawQtyVal < 0 ? 'SHORT' : 'LONG';
          const absQty = Math.abs(rawQtyVal);

          const avgPrice = parseFloat(String(
            p.avgPrice ?? p.entryPrice ?? p.avg_price ?? p.openPrice ?? 0));
          const markPrice = p.markPrice != null ? parseFloat(String(p.markPrice)) : null;

          const unrealizedPnl = (() => {
            const raw = p.unrealizedPnl ?? p.unRealizedProfit ?? p.unrealizedProfit ??
                        p.unrealisedPnl ?? p.pnl ?? null;
            if (raw === null || raw === undefined) return null;
            const n = parseFloat(String(raw));
            return isNaN(n) ? null : n;
          })();

          const positionValue = (() => {
            const raw = p.positionValue ?? p.notionalValue ?? p.notional ?? p.marketValue ?? p.value ?? null;
            if (raw !== null && raw !== undefined) {
              const n = parseFloat(String(raw));
              if (!isNaN(n) && n !== 0) return Math.abs(n);
            }
            // Confirmed Pionex formula: abs(netSize) × markPrice
            if (markPrice !== null && absQty > 0) return Math.abs(markPrice * absQty);
            return null;
          })();

          const occupiedMargin = (() => {
            const raw = p.occupiedMargin ?? p.margin ?? p.isolatedMargin ??
                        p.positionInitialMargin ?? p.initialMargin ?? null;
            if (raw === null || raw === undefined) return null;
            const n = parseFloat(String(raw));
            return isNaN(n) ? null : n;
          })();

          const liquidationPrice = (() => {
            const raw = p.liquidationPrice ?? p.liqPrice ?? p.forceClosePrice ?? null;
            if (raw === null || raw === undefined) return null;
            const n = parseFloat(String(raw));
            return isNaN(n) ? null : n;
          })();

          const leverage     = parseInt(String(p.leverage ?? 1), 10);
          const marginTypeRaw = String(
            p.marginMode ?? p.marginType ?? p.margin_type ?? p.marginLevel ?? 'cross'
          ).toLowerCase();
          const marginMode: 'Cross' | 'Isolated' =
            marginTypeRaw === 'isolated' ? 'Isolated' : 'Cross';

          let unrealizedPnlPct: number | null = null;
          if (unrealizedPnl !== null && positionValue !== null && positionValue !== 0) {
            unrealizedPnlPct = unrealizedPnl / positionValue;
          }

          return {
            symbol:             normaliseSymbolDisplay(rawSymbol),
            raw_symbol:         rawSymbol,
            side,
            margin_mode:        marginMode,
            leverage,
            quantity:           absQty,
            avg_price:          avgPrice,
            mark_price:         markPrice,
            position_value:     positionValue,
            unrealized_pnl:     unrealizedPnl,
            unrealized_pnl_pct: unrealizedPnlPct,
            occupied_margin:    occupiedMargin,
            liquidation_price:  liquidationPrice,
          };
        })
        // Active = explicit side OR non-zero qty
        .filter(p => {
          const rawP = rawPositions.find(r =>
            String(r.symbol ?? r.pair ?? r.contract ?? '') === p.raw_symbol);
          const expSide = String(rawP?.positionSide ?? rawP?.side ?? '').toUpperCase();
          return expSide === 'LONG' || expSide === 'SHORT' || p.quantity > 0;
        });

      await supabase.from('pionex_connections')
        .update({ last_sync: new Date().toISOString() })
        .eq('user_id', user.id);

      // positions_api_ok: true = API responded (0 positions is valid empty state)
      //                   false = API call failed (do NOT show "no positions" to user)
      return respond({ balances, open_orders, bots, positions, positions_api_ok: positionsFetched, positions_api_error: positionsApiError, source: 'pionex' });
    }

    // ── AUTHENTICATED: fetch USDT-M positions only (lightweight refresh) ───
    if (action === 'positions') {
      const { data: conn } = await supabase
        .from('pionex_connections')
        .select('api_key, api_secret_encrypted, is_connected')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!conn?.is_connected)
        return respond({ error: 'Pionex not connected' }, 404);

      const apiSecret = await decryptSecret(conn.api_secret_encrypted);

      // Use raw fetcher — never throws on result:false, so we always see the real payload.
      // This is the critical fix: pionexAuthRequest throws on result:false which was silently
      // swallowing the real Pionex error and returning 0 positions instead of an error state.
      const { httpStatus, body: rawBody } = await pionexRawRequest(
        'GET', PIONEX_USDTM_POSITIONS_PATH, conn.api_key, apiSecret
      );

      // Full safe diagnostic — keys only, no credential values
      console.log('[positions] HTTP', httpStatus,
        '| result:', rawBody.result,
        '| code:', rawBody.code,
        '| message:', rawBody.message,
        '| data keys:', rawBody.data != null ? Object.keys(rawBody.data as object) : 'null',
        '| top-level keys:', Object.keys(rawBody));

      // Auth / API error — return it clearly so UI shows error, NOT "no positions"
      if (rawBody.result === false || httpStatus !== 200) {
        const apiErr = String(rawBody.message ?? rawBody.code ?? `HTTP ${httpStatus}`);
        console.warn('[positions] API returned error:', apiErr);
        return respond({
          positions: [],
          positions_api_ok: false,
          positions_api_error: apiErr,
          _diag: { httpStatus, code: rawBody.code, message: rawBody.message },
        });
      }


      // ── Parse positions: try every known Pionex data envelope shape ──────
      const d = rawBody.data as Record<string, unknown> | null;
      let rawPos: Record<string, unknown>[] = [];
      if (Array.isArray(rawBody.data))                rawPos = rawBody.data as Record<string, unknown>[];
      else if (d && Array.isArray(d.positions))        rawPos = d.positions as Record<string, unknown>[];
      else if (d && Array.isArray(d.list))             rawPos = d.list as Record<string, unknown>[];
      else if (d && Array.isArray(d.data))             rawPos = d.data as Record<string, unknown>[];

      // Log ALL keys on every raw position so we can identify the real quantity field name
      console.log('[positions] raw count before filter:', rawPos.length);
      rawPos.forEach((p, i) => {
        console.log(`[positions] raw[${i}] ALL_KEYS:`, JSON.stringify(Object.keys(p)));
        console.log(`[positions] raw[${i}] FULL:`, JSON.stringify(p));
      });

      // Resolve quantity from the raw position object.
      // Pionex USDT-M /uapi/v1/account/positions uses 'positionAmt' per their API docs.
      // We also try every other known futures API field name as fallback.
      // IMPORTANT: skip exact zero values on first pass so a "0" positionAmt does not
      // shadow a non-zero value in another field (e.g. size=-520).
      // Object.is(n, 0) catches both +0 and -0 (JavaScript negative zero).
      function resolveQty(p: Record<string, unknown>): { value: number; field: string } {
        const candidates: Array<[string, unknown]> = [
          // Confirmed from live Pionex /uapi/v1/account/positions response:
          // netSize = -520 (signed, negative = SHORT)
          ['netSize',       p.netSize],
          // Other Pionex fields present in response (sizeShort is also -520 for SHORT)
          ['sizeShort',     p.side === 'SHORT' ? p.sizeShort : undefined],
          ['sizeLong',      p.side === 'LONG'  ? p.sizeLong  : undefined],
          // Generic futures API field names as fallback
          ['positionAmt',   p.positionAmt],
          ['size',          p.size],
          ['quantity',      p.quantity],
          ['qty',           p.qty],
          ['amount',        p.amount],
          ['vol',           p.vol],
          ['volume',        p.volume],
          ['pos',           p.pos],
          ['net',           p.net],
          ['holdSize',      p.holdSize],
          ['currentQty',    p.currentQty],
          ['contractSize',  p.contractSize],
        ];
        // First pass: non-zero numeric value (skips both +0 and -0)
        for (const [field, val] of candidates) {
          if (val !== undefined && val !== null && val !== '') {
            const n = parseFloat(String(val));
            if (!isNaN(n) && !Object.is(n, 0) && n !== 0) return { value: n, field };
          }
        }
        // Second pass: accept any numeric (fallback for all-zero position state)
        for (const [field, val] of candidates) {
          if (val !== undefined && val !== null && val !== '') {
            const n = parseFloat(String(val));
            if (!isNaN(n)) return { value: n, field };
          }
        }
        return { value: 0, field: 'none' };
      }

      const positions = rawPos
        .map(p => {
          const rawSymbol      = String(p.symbol ?? p.pair ?? p.contract ?? '');
          const explicitSide   = String(p.positionSide ?? p.side ?? '').toUpperCase();
          const { value: rawQtyVal, field: qtyField } = resolveQty(p);

          // Side: explicit positionSide wins; fall back to sign of quantity
          // SHORT positions have negative qty (e.g. -520) — preserve the sign for side detection
          let side: 'LONG' | 'SHORT';
          if (explicitSide === 'SHORT')      side = 'SHORT';
          else if (explicitSide === 'LONG')  side = 'LONG';
          else                               side = rawQtyVal < 0 ? 'SHORT' : 'LONG';

          // Display quantity is always absolute — side badge shows direction
          const absQty = Math.abs(rawQtyVal);

          // Trace log: shows exactly why a position is accepted or would be rejected
          console.log(`[positions] normalize: ${rawSymbol}/${explicitSide}`,
            `| qtyField=${qtyField} rawQty=${rawQtyVal} absQty=${absQty}`,
            `| normalizedSymbol=${normaliseSymbolDisplay(rawSymbol)} side=${side}`);

          // avgPrice: Pionex USDT-M uses avgPrice; also try entryPrice/openPrice
          const avgPrice = parseFloat(String(
            p.avgPrice ?? p.entryPrice ?? p.avg_price ?? p.openPrice ?? 0));

          // markPrice: standard across most APIs
          const markPrice = p.markPrice != null ? parseFloat(String(p.markPrice)) : null;

          // unrealizedPnl: try all known names — Pionex USDT-M API name TBD from diag
          const unrealizedPnl = (() => {
            const raw =
              p.unrealizedPnl      ?? p.unrealizedPnL    ?? p.unRealizedProfit ??
              p.unrealizedProfit   ?? p.unrealisedPnl    ?? p.unrealisedProfit ??
              p.openPnl            ?? p.floatingPnl      ?? p.floatProfit      ??
              p.pnl                ?? p.profit           ?? null;
            if (raw === null || raw === undefined) return null;
            const n = parseFloat(String(raw));
            return isNaN(n) ? null : n;
          })();

          // positionValue: Pionex /uapi/v1/account/positions has no explicit notional field.
          // Confirmed formula: abs(netSize) × markPrice = abs(-520) × 0.06704 ≈ 34.86 USDT
          // Try any explicit field first; fall back to the confirmed calculation.
          const positionValue = (() => {
            const raw =
              p.positionValue  ?? p.notionalValue ?? p.notional      ??
              p.marketValue    ?? p.mktValue      ?? p.value         ??
              p.positionNotional ?? p.contractValue ?? null;
            if (raw !== null && raw !== undefined) {
              const n = parseFloat(String(raw));
              if (!isNaN(n) && n !== 0) return Math.abs(n);
            }
            // Primary fallback: abs(netSize) × markPrice (confirmed correct for Pionex)
            if (markPrice !== null && absQty > 0) return Math.abs(markPrice * absQty);
            return null;
          })();

          // occupiedMargin: Pionex may use occupiedMargin, margin, or isolatedMargin
          const occupiedMargin = (() => {
            const raw =
              p.occupiedMargin       ?? p.margin             ??
              p.isolatedMargin       ?? p.positionInitialMargin ??
              p.initialMargin        ?? p.maintenanceMargin  ?? null;
            if (raw === null || raw === undefined) return null;
            const n = parseFloat(String(raw));
            return isNaN(n) ? null : n;
          })();

          // liquidationPrice: standard name, also try liqPrice
          const liquidationPrice = (() => {
            const raw = p.liquidationPrice ?? p.liqPrice ?? p.forceClosePrice ?? null;
            if (raw === null || raw === undefined) return null;
            const n = parseFloat(String(raw));
            return isNaN(n) ? null : n;
          })();

          // leverage: integer
          const leverage = parseInt(String(p.leverage ?? 1), 10);

          // marginMode: Pionex may use marginMode, marginType, or marginLevel
          const marginTypeRaw = String(
            p.marginMode ?? p.marginType ?? p.margin_type ?? p.marginLevel ?? 'cross'
          ).toLowerCase();
          const marginMode: 'Cross' | 'Isolated' =
            marginTypeRaw === 'isolated' ? 'Isolated' : 'Cross';

          // unrealizedPnlPct: use raw from Pionex if available, otherwise compute
          let unrealizedPnlPct: number | null = null;
          const rawPct = p.unrealizedPnlPct ?? p.unrealizedPnLPct ?? p.pnlPct ??
                         p.returnRate ?? p.roe ?? null;
          if (rawPct !== null && rawPct !== undefined) {
            const n = parseFloat(String(rawPct));
            if (!isNaN(n)) {
              // Pionex may return percentage as -2.28 (percent) or -0.0228 (decimal)
              // If absolute value > 1, it's already a percentage — convert to decimal
              unrealizedPnlPct = Math.abs(n) > 1 ? n / 100 : n;
            }
          } else if (unrealizedPnl !== null && positionValue !== null && positionValue !== 0) {
            unrealizedPnlPct = unrealizedPnl / positionValue;
          }

          // Mapping trace log — shows RAW field → NORMALIZED → UI value
          console.log(`[positions] mapping ${rawSymbol}:`,
            `avgPrice(raw=${p.avgPrice ?? p.entryPrice})=${avgPrice}`,
            `markPrice(raw=${p.markPrice})=${markPrice}`,
            `unrealizedPnl(raw=${p.unrealizedPnl ?? p.unRealizedProfit ?? p.pnl})=${unrealizedPnl}`,
            `positionValue(raw=${p.positionValue ?? p.notional})=${positionValue}`,
            `occupiedMargin(raw=${p.occupiedMargin ?? p.margin})=${occupiedMargin}`,
            `liqPrice(raw=${p.liquidationPrice ?? p.liqPrice})=${liquidationPrice}`,
            `leverage=${leverage} marginMode=${marginMode} qtyField=${qtyField} qty=${absQty}`
          );

          return {
            symbol:             normaliseSymbolDisplay(rawSymbol),
            raw_symbol:         rawSymbol,
            side,
            margin_mode:        marginMode,
            leverage,
            quantity:           absQty,
            avg_price:          avgPrice,
            mark_price:         markPrice,
            position_value:     positionValue,
            unrealized_pnl:     unrealizedPnl,
            unrealized_pnl_pct: unrealizedPnlPct,
            occupied_margin:    occupiedMargin,
            liquidation_price:  liquidationPrice,
            _qty_field:         qtyField,
          };
        })
        // Active = explicit positionSide LONG/SHORT OR non-zero quantity
        .filter(p => {
          const rawP = rawPos.find(r =>
            String(r.symbol ?? r.pair ?? r.contract ?? '') === p.raw_symbol);
          const expSide = String(rawP?.positionSide ?? rawP?.side ?? '').toUpperCase();
          const hasExplicitSide = expSide === 'LONG' || expSide === 'SHORT';
          const accepted = hasExplicitSide || p.quantity > 0;
          console.log(`[positions] filter: ${p.raw_symbol}/${p.side}`,
            `| hasExplicitSide=${hasExplicitSide} qty=${p.quantity}`,
            `| qtyField=${p._qty_field} accepted=${accepted}`);
          return accepted;
        });

      console.log('[positions] after filter:', positions.length,
        '| symbols:', positions.map(p => p.raw_symbol).join(',') || '(none)');

      return respond({
        positions,
        positions_api_ok: true,
        positions_api_error: null,
        // Include raw positions for client-side debugging (no credentials, safe)
        _raw_positions: rawPos.map(p => ({ ...p })),
      });
    }

    // ── AUTHENTICATED: diagnostic — full raw Pionex response, all field names ──
    if (action === 'diag_positions') {
      const { data: conn } = await supabase
        .from('pionex_connections')
        .select('api_key, api_secret_encrypted, is_connected')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!conn?.is_connected)
        return respond({ error: 'Pionex not connected' }, 404);

      const apiSecret = await decryptSecret(conn.api_secret_encrypted);

      const { httpStatus, body: rawBody } = await pionexRawRequest(
        'GET', PIONEX_USDTM_POSITIONS_PATH, conn.api_key, apiSecret
      );

      // Extract position array from every known envelope shape
      const dd = rawBody.data as Record<string, unknown> | null;
      let rawArr: Record<string, unknown>[] = [];
      if (Array.isArray(rawBody.data))              rawArr = rawBody.data as Record<string, unknown>[];
      else if (dd && Array.isArray(dd.positions))   rawArr = dd.positions as Record<string, unknown>[];
      else if (dd && Array.isArray(dd.list))        rawArr = dd.list as Record<string, unknown>[];
      else if (dd && Array.isArray(dd.data))        rawArr = dd.data as Record<string, unknown>[];

      // Return every raw key on every position so the UI can show exactly what Pionex sent
      return respond({
        endpoint:       PIONEX_USDTM_POSITIONS_PATH,
        http_status:    httpStatus,
        result:         rawBody.result,
        code:           rawBody.code,
        message:        rawBody.message,
        timestamp:      rawBody.timestamp,
        top_level_keys: Object.keys(rawBody),
        position_count: rawArr.length,
        // Full raw positions including all field names and values
        raw_positions:  rawArr.map(p => ({ ...p })),
        // Convenience: just the keys on the first position
        position_keys:  rawArr.length > 0 ? Object.keys(rawArr[0]) : [],
      });
    }

    return respond({ error: 'Unknown action' }, 400);

  } catch (err) {
    console.error('pionex-proxy error:', err);
    return respond({ error: String(err) }, 500);
  }
});
